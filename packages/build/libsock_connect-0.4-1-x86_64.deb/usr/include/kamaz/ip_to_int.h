#ifndef _LIB_SOCK_CONNECT_IP_TO_INT_H
#define _LIB_SOCK_CONNECT_IP_TO_INT_H

/**
 * Transform <const char*> IP-address to uint32_t
 * "127.0.0.1" -> 0x7f000001
 */
unsigned int ip_to_int(const char *ip);

#endif // _LIB_SOCK_CONNECT_IP_TO_INT_H
